﻿namespace WindowsFormsApp1
{


    public partial class DataSet1
    {
        partial class JobDataTable
        {
        }

        partial class EmployeeDataTable
        {
        }
    }
}
